<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl">Administración</h2>
    </x-slot>

    <div class="py-6 max-w-7xl mx-auto">
        <div class="bg-white p-6 shadow rounded">
            <p class="text-gray-600">
                Gestión de usuarios, roles y configuración del sistema.
            </p>
        </div>
    </div>
</x-app-layout>
