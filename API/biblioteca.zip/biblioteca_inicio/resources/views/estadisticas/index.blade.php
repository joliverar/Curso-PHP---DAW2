<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl">Estadísticas</h2>
    </x-slot>

    <div class="py-6 max-w-7xl mx-auto">
        <div class="bg-white p-6 shadow rounded">
            <ul class="list-disc ml-5 text-gray-600">
                <li>Total de préstamos</li>
                <li>Libros más prestados</li>
                <li>Usuarios activos</li>
            </ul>
        </div>
    </div>
</x-app-layout>
