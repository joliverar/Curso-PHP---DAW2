import './bootstrap';
import { createApp } from 'vue';
// componente raíz — crea resources/js/App.vue (ejemplo abajo)
import App from './App.vue';

createApp(App).mount('#app');
