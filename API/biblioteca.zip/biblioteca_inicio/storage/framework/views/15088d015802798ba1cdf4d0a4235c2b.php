<?php $__env->startSection('content'); ?>
  <h1><?php echo e($author->name); ?></h1>

  <p><strong>País:</strong> <?php echo e($author->country ?? '-'); ?></p>
  <p><strong>Nacimiento:</strong> <?php echo e(optional($author->birth_date)->format('Y-m-d') ?? '-'); ?></p>

  <p>
    <a href="<?php echo e(route('authors.edit', $author)); ?>">Editar</a>
    <a href="<?php echo e(route('authors.index')); ?>">Volver</a>
  </p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp_82\htdocs\Curso-PHP---DAW2\API\biblioteca_inicio\resources\views/authors/show.blade.php ENDPATH**/ ?>